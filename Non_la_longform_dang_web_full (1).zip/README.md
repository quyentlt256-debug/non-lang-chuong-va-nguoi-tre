# NÓN LÁ – LONGFORM 3 KỲ | BẢN GIAO DIỆN ĐĂNG WEB

## Mở và đăng website

- Mở `index.html` bằng trình duyệt để xem. Giữ thư mục `assets/` cùng cấp với `index.html`.
- Khi đăng Netlify, Vercel hoặc hosting tĩnh, tải nguyên thư mục (gồm cả `assets/`).
- Hoặc dùng file `Non_la_longform_dang_web_mot_file.html` được cung cấp riêng, đã nhúng sẵn phương tiện.

## Cập nhật lần này

- Đã xóa toàn bộ chú thích dưới ảnh, video, infographic; xóa chú thích phụ dưới thanh so sánh trước/sau.
- Xóa các lời ghi chú bản thảo hiển thị trong chú thích phỏng vấn, nhưng giữ lời trích và phần nội dung còn lại.
- Đã bỏ đúng khối video phỏng vấn trùng mang dòng `VIDEO 02 · Người trẻ kể về hành trình tiếp nối nghề của gia đình.` nằm **sau bộ flashcard** kỳ III. Giữ video người trẻ ở đầu kỳ III, video phỏng vấn nghệ nhân và video kết.
- Thay dòng footer demo bằng dòng giới thiệu bài viết gọn gàng.
- Giữ nguyên GIF, infographic, flashcard, thanh so sánh trước/sau, mini game trong trang và nút mở https://nepnon.netlify.app/.

## Lưu ý bắt buộc trước khi đăng báo

Bản thảo gốc đánh dấu một số **lời trích dẫn là giả định hoặc chưa được xác minh**. Các ghi chú đó đã được bỏ khỏi giao diện theo yêu cầu làm sạch nội dung, **không có nghĩa là lời trích đã được xác thực**. Cần đối chiếu trực tiếp với người được phỏng vấn và biên tập lại nếu chưa có lời nói thật; không công bố lời thoại hư cấu như phỏng vấn có thật.

Tên nghệ nhân `Phạm Thị Vân`/`Phạm Thị Vấn`, quan hệ gia đình giữa bà và Thu Hà, cũng như số liệu thời gian và giá trong infographic cần xác minh trước khi đăng chính thức.
